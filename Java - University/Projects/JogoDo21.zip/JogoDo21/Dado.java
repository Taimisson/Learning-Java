import java.util.Random;

// Classe dado em Java
public class Dado{
    private int dadoLados;
    private String cor;
    
    public Dado(String cor){
        this.dadoLados = 6;
        this.cor = cor;
    }

    public void setdadoLados(int dadoLados){
        this.dadoLados = dadoLados;
    }
    
    public void setCor(String cor){
        this.cor = cor;
    }
    
    public int getDadoLados(){
        return dadoLados;
    }
    
    public String getCor(){
         return cor;
    }
    
    public int jogarDado(){
        int numeroAleatorio = (int)(Math.random()  * 6) + 1;
        return numeroAleatorio;
    }
    
    public String toString(){
        return "Dado: 6 lados e cor: " + cor;
    }
    
}