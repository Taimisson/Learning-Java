public class Jogo{
    private Jogador jogador1;
    private Jogador jogador2;
    private ASCII ascii;
    
    public Jogo(){
        this.jogador1 = new Jogador(Teclado.leString("NOME DO PRIMEIRO JOGADOR"));
        this.jogador2 = new Jogador(Teclado.leString("NOME DO SEGUNDO JOGADOR"));
        this.ascii = new ASCII();
    }
    
    public void setNomeJogador1(Jogador nomeJogador1){
        this.jogador1 = nomeJogador1;
    }
    
    public void setNomeJogador2(Jogador nomeJogador2){
        this.jogador2 = nomeJogador2;
    }
    
    public Jogador getNomeJogador1(){
        return jogador1;
    }
    
    public Jogador getNomeJogador2(){
        return jogador2;
    }
    
    public void inicioJogo(){
        jogador1.zerarPontuacao();
        jogador2.zerarPontuacao();
    }
    public void regrasJogo(){
        Utilitarios.centralizarTexto(" > O JOGO DO 21 < ");
        
    }
    public void comecaJogo(){
        boolean respostaJogar = false;
        do{
            inicioJogo();    
            if (respostaJogar)
                new Jogo();
                
            
            Utilitarios.centralizarTexto(" [INICIANDO O JOGO]");
            int rodada = 1;
            do{
                 Utilitarios.centralizarTextoBranco(" RODADA " + rodada + " ");
                 
                 jogada(jogador1);
                 Utilitarios.centralizarTexto("");
                 Utilitarios.linhaEmBranco();
                 jogada(jogador2);
                 
                 Utilitarios.centralizarTexto(" [FIM DA RODADA " + rodada +"] ");
                 rodada++;
                 
                
            } while (rodada <= 3);
             
            Utilitarios.centralizarTextoBranco("");
            Utilitarios.centralizarTexto(" [FIM DO JOGO] ");
            Utilitarios.centralizarTextoBranco("");
            
            String nomeJogador1 = jogador1.getNome();
            String nomeJogador2 = jogador2.getNome();
            int ptJogador1 = jogador1.getPontos();
            int ptJogador2 = jogador2.getPontos();
            
            if(ptJogador1 > 21 && ptJogador2 > 21)
                Utilitarios.centralizarTextoBranco("OS JOGADORES EMPATARAM!");
            else if(ptJogador1 > 21)
                Utilitarios.centralizarTextoBranco("O JOGADOR " + nomeJogador2 + " VENCEU!");
            else if(ptJogador2 > 21)
                Utilitarios.centralizarTextoBranco("O JOGADOR " + nomeJogador1 + " VENCEU!");
            else if(ptJogador1 == ptJogador2)
                Utilitarios.centralizarTextoBranco("O JOGO TERMINOU EMPATADO!");
            else
                Utilitarios.centralizarTextoBranco(ptJogador1 > ptJogador2 ? nomeJogador1 + " VENCEU!" : nomeJogador2 + " VENCEU!");
            
            Utilitarios.centralizarTextoBranco("");
            Utilitarios.centralizarTextoBranco(nomeJogador1 + ": " + ptJogador1);
            Utilitarios.centralizarTextoBranco(nomeJogador2 + ": " + ptJogador2);
            Utilitarios.linhaEmBranco();
            
            Utilitarios.centralizarTexto("");
            
            Utilitarios.linhaEmBranco();
            char resposta = Teclado.leString("DESEJAM JOGAR NOVAMENTE? [SIM/NÃO]").toLowerCase().charAt(0);
            respostaJogar = resposta == 's';
            
            
            }while(respostaJogar);
        }
    public void jogada(Jogador jogador){
        System.out.println("VEZ DE " + jogador.getNome());
        Utilitarios.linhaEmBranco();
        
        int escolha;
        
        while(true){
            escolha = Teclado.leInt("1 - JOGAR \n2 - PASSAR A VEZ");
            
            if(escolha == 1 || escolha == 2)
                break;
            else
                System.out.println("[ERRO] Escolha inválida. Tente novamente!");
        }            
        switch(escolha){
            case 1:
                int resultado1 = jogador.jogarDadoBranco();
                int resultado2 = jogador.jogarDadoVermelho();
                
                Utilitarios.centralizarTextoBranco(" DADO BRANCO | DADO VERMELHO ");
                ascii.exibirCombinação(resultado1, resultado2);
                
                if (resultado2 == 6){
                    resultado2 *= 2;
                    int soma = resultado1 + resultado2;
                    jogador.setPontos(soma);
                    Utilitarios.centralizarTextoBranco(" [AVISO] TIROU 6 NO DADO VERMELHO E O VALOR SERÁ DUPLICADO EM 2X!");
                }
                
                int soma = resultado1 + resultado2;
                int pontosTotais = jogador.getPontos();
                Utilitarios.centralizarTextoBranco("PONTOS RODADA: " + soma + " | PONTOS PARTIDA: " + pontosTotais);
                Utilitarios.linhaEmBranco();
                break;
            case 2:
                Utilitarios.centralizarTextoBranco("> "+ jogador.getNome() + " PASSOU A VEZ < \n");
                break;
        }
        
        
    }
}