public class Jogador{
    private String nome;
    private int pontos;
    private Dado dadoBranco;
    private Dado dadoVermelho;
    
    // Método construdor do jogador
    public Jogador(String nome){
        this.nome = nome;
        this.pontos = 0; 
        this.dadoBranco = new Dado("Branco");
        this.dadoVermelho = new Dado("Vermelho");
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setPontos(int pontos){
        this.pontos = pontos;
    }
    public void setDadoBranco(Dado dadoBranco){
        this.dadoBranco = dadoBranco;
    }
    public void setDadoVermelho(Dado dadoVermelho){
        this.dadoVermelho = dadoVermelho;
    }
    
    public String getNome(){
        return nome;
    }
    public int getPontos(){
        return pontos;
    }
    public Dado getDadoBranco(){
        return dadoBranco;
    }
    public Dado getDadoVermelho(){
        return dadoVermelho;
    }
    
    public int jogarDadoBranco(){
        int resultado = dadoBranco.jogarDado();
        pontos += resultado; 
        return resultado;
    }
    
    public int jogarDadoVermelho(){
        int resultado = dadoVermelho.jogarDado();
        pontos += resultado;
        return resultado;
    }
    
    public void zerarPontuacao(){
        this.pontos = 0;
    }
}