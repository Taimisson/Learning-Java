public class Utilitarios{
    public static void linhaEmBranco(){
        System.out.println();
    }
    
    public static void centralizarTexto(String texto) {
        char caractereDePreenchimento = '=';
        int larguraTotal = 50;
        
        int comprimentoTexto = texto.length();
        if (comprimentoTexto >= larguraTotal) {
            System.out.println(texto);
        } else {
            int espacosAntes = (larguraTotal - comprimentoTexto) / 2;
            int espacosDepois = larguraTotal - comprimentoTexto - espacosAntes;

            StringBuilder linhaCentralizada = new StringBuilder();

            for (int i = 0; i < espacosAntes; i++) {
                linhaCentralizada.append(caractereDePreenchimento);
            }

            linhaCentralizada.append(texto);

            for (int i = 0; i < espacosDepois; i++) {
                linhaCentralizada.append(caractereDePreenchimento);
            }

            System.out.println(linhaCentralizada.toString());
        }
    }
    public static void centralizarTextoBranco(String texto) {
        int comprimentoTexto = texto.length();
        if (comprimentoTexto >= 50) {
            System.out.println(texto); // Texto é maior ou igual à largura desejada, imprime sem centralizar
        } else {
            int espacosAntes = (50 - comprimentoTexto) / 2;
            int espacosDepois = 50 - comprimentoTexto - espacosAntes;

            StringBuilder linhaCentralizada = new StringBuilder();

            for (int i = 0; i < espacosAntes; i++) {
                linhaCentralizada.append(' ');
            }

            linhaCentralizada.append(texto);

            for (int i = 0; i < espacosDepois; i++) {
                linhaCentralizada.append(' ');
            }

            System.out.println(linhaCentralizada.toString());
        }
    }
}