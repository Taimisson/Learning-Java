public class Principal{
    public static void main(String[] args){
        
        Jogo jogo = new Jogo();
        jogo.comecaJogo();
        
    }
}