public class ASCII {
    public static void main(String[] args) {
        exibirCombinacoesDeDados();
    }

    public static void exibirCombinacoesDeDados() {
        // Loop para o dado 1 (de 1 a 6)
        for (int d1 = 1; d1 <= 6; d1++) {
            // Loop para o dado 2 (de 1 a 6)
            for (int d2 = 1; d2 <= 6; d2++) {
                // Exiba a combinação atual
                exibirCombinação(d1, d2);
            }
        }
    }

    public static void exibirCombinação(int dado1, int dado2) {
        Utilitarios.centralizarTextoBranco(" _______    _______ ");
        Utilitarios.centralizarTextoBranco("|       |  |       |");
        Utilitarios.centralizarTextoBranco("|   " + dado1 + "   |  |   " + dado2 + "   |");
        Utilitarios.centralizarTextoBranco("|       |  |       |");
        Utilitarios.centralizarTextoBranco("|_______|  |_______|");
        Utilitarios.centralizarTextoBranco("");
    }
}
