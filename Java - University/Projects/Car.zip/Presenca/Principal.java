import java.sql.SQLOutput;

public class Principal {
    public static void main(String[] args) {
        Carro carro = novoCarro();

        System.out.println(carro);

        carro.getPlaca().setNumero("GREM100");
        System.out.println();
        System.out.println(carro.getPlaca().getNumero());
        System.out.println();

        System.out.println(carro.getPlaca());

    }

    public static Placa novaPlaca() {
        String pais = Teclado.leString("Digite o nome do país: ");
        String numero = Teclado.leString("Número da Placa: ");

        return new Placa(pais, numero);
    }

    public static Carro novoCarro() {
        String cor = Teclado.leString("Cor: ");
        String marca = Teclado.leString("Marca: ");
        String nome = Teclado.leString("Nome: ");
        Placa placa = novaPlaca();

        return new Carro(cor, marca, nome, placa);
    }
}