//Crie uma class Carro, que possui uma cor, uma marca, um nome e uma placa (do tipo Placa). Crie um construtor, os métodos de acesso e um toString para a classe.
public class Carro {
    private String cor;
    private String marca;
    private String nome;
    private Placa placa;

    public Carro(String cor, String marca, String nome, Placa placa) {
        this.cor = cor;
        this.marca = marca;
        this.nome = nome;
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Placa getPlaca() {
        return placa;
    }

    public void setPlaca(Placa placa) {
        this.placa = placa;
    }

    @Override
    public String toString() {
        return "Carro" +
                "\nCor: " + cor +
                "\nMarca: " + marca +
                "\nNome: " + nome +
                "\nPlaca: " + placa;
    }
}
