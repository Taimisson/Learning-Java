public class Placa {
    private String pais;
    private String numero;

    public Placa(String pais, String numero) {
        this.pais = pais;
        this.numero = numero;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Placa" +
                "\nPaís: " + pais +
                "\nNúmero: " + numero;
    }
}
