//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Teclado {
    private static String s;
    private static InputStreamReader i;
    private static BufferedReader d;

    public Teclado() {
    }

    public static int leInt() {
        int a = 0;

        try {
            s = d.readLine();
            a = Integer.parseInt(s);
        } catch (IOException var2) {
            System.out.println("Erro de I/O: " + String.valueOf(var2));
        } catch (NumberFormatException var3) {
            System.out.println("o valor digitado deve ser inteiro: " + String.valueOf(var3));
        }

        return a;
    }

    public static int leInt(String msg) {
        int a = 0;
        System.out.println(msg);

        try {
            s = d.readLine();
            a = Integer.parseInt(s);
        } catch (IOException var3) {
            System.out.println("Erro de I/O: " + String.valueOf(var3));
        } catch (NumberFormatException var4) {
            System.out.println("o valor digitado deve ser inteiro: " + String.valueOf(var4));
        }

        return a;
    }

    public static double leDouble() {
        double a = 0.0;

        try {
            s = d.readLine();
            a = Double.parseDouble(s);
        } catch (IOException var3) {
            System.out.println("Erro de I/O: " + String.valueOf(var3));
        } catch (NumberFormatException var4) {
            System.out.println("o valor digitado deve ser número: " + String.valueOf(var4));
        }

        return a;
    }

    public static double leDouble(String msg) {
        double a = 0.0;
        System.out.println(msg);

        try {
            s = d.readLine();
            a = Double.parseDouble(s);
        } catch (IOException var4) {
            System.out.println("Erro de I/O: " + String.valueOf(var4));
        } catch (NumberFormatException var5) {
            System.out.println("o valor digitado deve ser numero: " + String.valueOf(var5));
        }

        return a;
    }

    public static String leString() {
        s = "";

        try {
            s = d.readLine();
        } catch (IOException var1) {
            System.out.println("Erro de I/O: " + String.valueOf(var1));
        }

        return s;
    }

    public static String leString(String msg) {
        s = "";
        System.out.println(msg);

        try {
            s = d.readLine();
        } catch (IOException var2) {
            System.out.println("Erro de I/O: " + String.valueOf(var2));
        }

        return s;
    }

    public static char leChar() {
        char a = ' ';

        try {
            s = d.readLine();
            a = s.charAt(0);
        } catch (IOException var2) {
            System.out.println("Erro de I/O: " + String.valueOf(var2));
        } catch (NumberFormatException var3) {
            System.out.println("o valor digitado deve ser char: " + String.valueOf(var3));
        }

        return a;
    }

    public static char leChar(String msg) {
        char a = ' ';
        System.out.println(msg);

        try {
            s = d.readLine();
            a = s.charAt(0);
        } catch (IOException var3) {
            System.out.println("Erro de I/O: " + String.valueOf(var3));
        } catch (NumberFormatException var4) {
            System.out.println("o valor digitado deve ser um char: " + String.valueOf(var4));
        }

        return a;
    }

    static {
        i = new InputStreamReader(System.in);
        d = new BufferedReader(i);
    }
}
