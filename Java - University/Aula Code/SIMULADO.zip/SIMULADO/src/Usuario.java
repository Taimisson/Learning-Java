import java.util.Arrays;

public class Usuario extends ContaFacebook {
    private Pessoa[] amigosUsuario;

    public Usuario(String url, String usuario, String senha) {
        super(url, usuario, senha);
        this.amigosUsuario = new Pessoa[1000];
    }

    public boolean insereAmigo(Pessoa pessoa) {
        for (int i = 0; i < amigosUsuario.length; i++) {
            if (amigosUsuario[i] == null) {
                amigosUsuario[i] = pessoa;
                return true;
            }
        }
        return false;
    }

    public Pessoa[] getAmigosUsuario() {
        return amigosUsuario;
    }

    public void setAmigosUsuario(Pessoa[] amigosUsuario) {
        this.amigosUsuario = amigosUsuario;
    }

    @Override
    public String toString() {
        return super.toString() + " Amigos" + Arrays.toString(amigosUsuario);
    }
}
