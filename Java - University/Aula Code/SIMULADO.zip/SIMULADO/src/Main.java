import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {

        System.out.println("Informe a quantidade de contas no Facebook:");
        int quantidadeContas = Teclado.leInt();
        Facebook facebook = new Facebook(quantidadeContas);

        for (int i = 0; i < quantidadeContas + 3; i++) {
            ContaFacebook conta;
            if (Math.random() < .5){
                conta = new Fanpage("facebook.com/fanpage", "fanpage", "senha123");
            } else {
                conta = new Usuario("facebook.com/taisoo", "taisoo", "senha321");
            }
            boolean inserido = facebook.insereConta(conta);
            System.out.println("Conta " + (i + 1) + (inserido ? " inserida." : " não inserida."));
        }


        facebook.imprimeInformacoesContas();
    }
}
