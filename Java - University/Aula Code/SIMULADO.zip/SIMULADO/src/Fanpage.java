public class Fanpage extends ContaFacebook {
    private int quantidadeCurtidas;

    public Fanpage(String url, String usuario, String senha) {
        super(url, usuario, senha);
        this.quantidadeCurtidas = 0;
    }

    public void curtir() {
        quantidadeCurtidas += 1;
    }

    public int getQuantidadeCurtidas() {
        return quantidadeCurtidas;
    }

    public void setQuantidadeCurtidas(int quantidadeCurtidas) {
        this.quantidadeCurtidas = quantidadeCurtidas;
    }

    @Override
    public String toString() {
        return super.toString() + " Quantidade de Curtidas: " + quantidadeCurtidas;
    }

}
