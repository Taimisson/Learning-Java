public class Facebook {
    private ContaFacebook[] contasFacebook;

    public Facebook(int quantidade) {
        this.contasFacebook = new ContaFacebook[quantidade];
    }

    public boolean insereConta(ContaFacebook contaFacebook) {
        for (int i = 0; i < contasFacebook.length; i++) {
            if (contasFacebook[i] == null) {
                contasFacebook[i] = contaFacebook;
                return true;
            }
        }
        return false;
    }

    public ContaFacebook[] getContasFacebook() {
        return contasFacebook;
    }

    public void setContasFacebook(ContaFacebook[] contasFacebook) {
        this.contasFacebook = contasFacebook;
    }

    public void imprimeInformacoesContas() {
        for (ContaFacebook contas : contasFacebook)
            System.out.println(contas);
    }

    public void imprimeURLFanpages() {
        for (ContaFacebook contas : contasFacebook)
            System.out.println(contas.getUrl());
    }
}
