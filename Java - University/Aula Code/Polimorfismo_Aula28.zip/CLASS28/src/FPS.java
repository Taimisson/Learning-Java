public class FPS extends Jogo {
    private String mapa;

    public FPS(String nome, int qntdJogadores, String mapa) {
        super(nome, qntdJogadores);
        this.mapa = mapa;
    }

    public String getMapa() {
        return mapa;
    }

    public void setMapa(String mapa) {
        this.mapa = mapa;
    }

    @Override
    public String toString() {
        return super.toString() + " Mapa: " + mapa;
    }
}

