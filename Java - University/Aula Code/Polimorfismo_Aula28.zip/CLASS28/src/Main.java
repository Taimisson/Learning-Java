
public class Main {
    public static void main(String[] args) {
        Jogo fps = new FPS("CounterStrike 2", 5, "Dust 2");
        Jogo moba = new MOBA("League of Legends", 5, 3);
        Jogo rpg = new RPG("The Witcher", 1, "Reino de Vizima");

        Jogo[] jogos = {fps, moba, rpg};

        BrasilGameShow BGS = new BrasilGameShow(jogos);

        System.out.println(BGS);

    }
}