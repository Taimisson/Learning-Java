public class MOBA extends Jogo{
    private int qntdRotas;

    public MOBA(String nome, int qntdJogadores, int qntdRotas) {
        super(nome, qntdJogadores);
        this.qntdRotas = qntdRotas;
    }

    public int getQntdRotas() {
        return qntdRotas;
    }

    public void setQntdRotas(int qntdRotas) {
        this.qntdRotas = qntdRotas;
    }

    @Override
    public String toString() {
        return super.toString() + " Quantidade de Rotas: " + qntdRotas;
    }
}
