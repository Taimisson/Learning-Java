public class RPG extends Jogo {
    private String cenario;

    public RPG(String nome, int qntdJogadores, String cenario) {
        super(nome, qntdJogadores);
        this.cenario = cenario;
    }

    public String getMundoAberto() {
        return cenario;
    }

    public void setMundoAberto(String mundoAberto) {
        this.cenario = mundoAberto;
    }

    @Override
    public String toString() {
        return super.toString() + " Cenário: ";
    }
}