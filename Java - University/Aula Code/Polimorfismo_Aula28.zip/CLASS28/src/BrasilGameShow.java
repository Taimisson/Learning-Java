public class BrasilGameShow {
    private Jogo[] jogos;

    public BrasilGameShow(Jogo[] jogos) {
        this.jogos = jogos;
    }

    public Jogo[] getJogos() {
        return jogos;
    }

    public void setJogos(Jogo[] jogos) {
        this.jogos = jogos;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();

        for (Jogo jogo : jogos)
            result.append(jogo).append("\n");

        return "JOGOS NO BRASIL GAME SHOW: \n" + result.toString();
    }

}
