public class Jogo {
    private String nome;
    private int qntdJogadores;

    public Jogo(String nome, int qntdJogadores) {
        this.nome = nome;
        this.qntdJogadores = qntdJogadores;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQntdJogadores() {
        return qntdJogadores;
    }

    public void setQntdJogadores(int qntdJogadores) {
        this.qntdJogadores = qntdJogadores;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + " Quantidade de Jogadores: " + qntdJogadores;
    }
}